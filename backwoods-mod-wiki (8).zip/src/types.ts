export interface WikiArticle {
  slug: string;
  filename: string;
  title: string;
  category: string;
  order: number;
}

export interface WikiManifest {
  articles: WikiArticle[];
}
